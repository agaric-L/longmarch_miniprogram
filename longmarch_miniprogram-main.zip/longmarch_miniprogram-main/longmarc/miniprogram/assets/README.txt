Place two PNG icons here for map markers:
- flag_on.png  (highlighted/reached node)
- flag_off.png (unreached node)

Recommended size: 48x48 px, transparent background.
Referenced by: /pages/map/map.js iconPath fields. 